# Improved Intra libraries
Any file in this directory is a library that is used by both the foreground
and background scripts for the Improved Intra browser extension.

## Libraries
- network.js: Contains functions for making network requests with the Improved Intra back-end server.
- storage.js: Contains functions for interacting with the Improved Intra browser extension's local storage in both incognito and normal mode.
