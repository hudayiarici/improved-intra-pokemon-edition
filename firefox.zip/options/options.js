/* ************************************************************************** */
/*                                                                            */
/*                                                        ::::::::            */
/*   options.js                                         :+:    :+:            */
/*                                                     +:+                    */
/*   By: fbes <fbes@student.codam.nl>                 +#+                     */
/*                                                   +#+                      */
/*   Created: 2021/11/28 02:23:39 by fbes          #+#    #+#                 */
/*   Updated: 2022/11/06 00:47:21 by fbes          ########   odam.nl         */
/*                                                                            */
/* ************************************************************************** */

// redirect to the new options page of the Improved Intra 42 extension
window.location.href = "/v2/options";
